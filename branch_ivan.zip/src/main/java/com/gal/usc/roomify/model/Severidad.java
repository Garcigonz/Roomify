package com.gal.usc.roomify.model;


public enum Severidad{
    LEVE,
    MEDIO,
    GRAVE,
    MUY_GRAVE
}
