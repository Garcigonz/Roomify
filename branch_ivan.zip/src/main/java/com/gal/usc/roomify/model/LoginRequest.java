package com.gal.usc.roomify.model;

public record LoginRequest(String id, String password) {}
